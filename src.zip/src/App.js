import React from "react";
import { Home } from "./components/Home.js";

function App() {
  return (
    <div className="App">
      <div>
        <Home />
      </div>
    </div>
  );
}

export default App;
